(function () {
    if (window.location.pathname.startsWith("/editor.html/content/demo")) {
        document.querySelector(".editor-EmulatorDeviceRotate").setAttribute("hidden", "true");
    }
})();